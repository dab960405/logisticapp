package com.example.LogisticAPP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogisticAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
