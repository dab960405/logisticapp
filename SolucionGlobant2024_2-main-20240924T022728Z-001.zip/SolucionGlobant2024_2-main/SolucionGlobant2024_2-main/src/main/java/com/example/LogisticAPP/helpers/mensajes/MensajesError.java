package com.example.LogisticAPP.helpers.mensajes;

public enum MensajesError {
    // Mensajes de Cliente
    NOMBRES_INVALIDOS("Los nombres son inválidos"),
    DEPARTAMENTO_INVALIDO("El departamento es inválido"),
    MUNICIPIO_INVALIDO("El municipio es inválido"),
    DIRECCION_INVALIDA("La dirección es inválida"),
    CODIGO_POSTAL_INVALIDO("El código postal es inválido"),
    ROL_INVALIDO("El rol es inválido"),
    EMAIL_INVALIDO("El email es inválido"),
    TELEFONO_INVALIDO("El teléfono es inválido"),
    CLIENTE_NO_ENCONTRADO("Cliente no encontrado"),

    // Mensajes de ZonaBodega
    ZONA_NO_ENCONTRADA("Zona de bodega no encontrada"),
    NOMBRE_ZONA_INVALIDO("El nombre de la zona es inválido"),
    CAPACIDAD_INVALIDA("La capacidad de la zona es inválida"),
    TIPO_ZONA_INVALIDO("El tipo de zona es inválido"),

    // Mensajes de Mercancia
    MERCANCIA_NO_ENCONTRADA("Mercancía no encontrada"),
    NOMBRE_MERCANCIA_INVALIDO("El nombre de la mercancía es inválido"),
    CATEGORIA_INVALIDA("La categoría de la mercancía es inválida"),
    CANTIDAD_INVALIDA("La cantidad de mercancía es inválida"),
    PRECIO_INVALIDO("El precio de la mercancía es inválido"),
    DESCRIPCION_INVALIDA("La descripción de la mercancía es inválida"),

    // Mensajes de Validación de Volumen y Peso
    VOLUMEN_INVALIDO("El volumen es inválido"),
    PESO_INVALIDO("El peso es inválido"),
    VOLUMEN_OCUPADO_INVALIDO("El volumen ocupado es inválido"),
    PESO_OCUPADO_INVALIDO("El peso ocupado es inválido");

    private final String mensaje;

    MensajesError(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getMensaje() {
        return mensaje;
    }
}
