package com.example.LogisticAPP.controladores;


import com.example.LogisticAPP.modelos.Cliente;
import com.example.LogisticAPP.servicios.ServicioCliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/logisticAPP/v1/clientes")
public class ClienteControlador {

    private final ServicioCliente clienteServicio;

    @Autowired
    public ClienteControlador(ServicioCliente clienteServicio) {
        this.clienteServicio = clienteServicio;
    }

    // Registrar un nuevo cliente
    @PostMapping
    public ResponseEntity<Cliente> registrarCliente(@RequestBody Cliente cliente) {
        try {
            Cliente nuevoCliente = clienteServicio.registrar(cliente);
            return new ResponseEntity<>(nuevoCliente, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    // Obtener todos los clientes
    @GetMapping
    public ResponseEntity<List<Cliente>> obtenerClientes() {
        try {
            List<Cliente> clientes = clienteServicio.buscarClientes();
            return new ResponseEntity<>(clientes, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

