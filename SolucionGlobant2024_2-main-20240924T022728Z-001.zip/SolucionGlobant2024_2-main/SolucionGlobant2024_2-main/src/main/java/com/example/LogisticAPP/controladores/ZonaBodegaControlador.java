package com.example.LogisticAPP.controladores;

import com.example.LogisticAPP.modelos.ZonaBodega;
import com.example.LogisticAPP.servicios.ZonaBodegaServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/logisticAPP/v1/zonabodega")
public class ZonaBodegaControlador {

    @Autowired
    private ZonaBodegaServicio zonaBodegaServicio;

    // Registrar una nueva zona de bodega
    @PostMapping
    public ResponseEntity<?> registrarZonaBodega(@RequestBody ZonaBodega datosZonaBodega) {
        try {
            ZonaBodega nuevaZona = zonaBodegaServicio.registrar(datosZonaBodega);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevaZona);
        } catch (Exception error) {
            HashMap<String, Object> respuestaError = new HashMap<>();
            respuestaError.put("mensaje", error.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuestaError);
        }
    }

    // Obtener todas las zonas de bodega
    @GetMapping
    public ResponseEntity<List<ZonaBodega>> obtenerZonasBodega() {
        try {
            List<ZonaBodega> zonasBodega = zonaBodegaServicio.buscarZonasBodega();
            return ResponseEntity.ok(zonasBodega);
        } catch (Exception error) {
            // En caso de error, puedes retornar una lista vacía o manejarlo de otra manera
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
