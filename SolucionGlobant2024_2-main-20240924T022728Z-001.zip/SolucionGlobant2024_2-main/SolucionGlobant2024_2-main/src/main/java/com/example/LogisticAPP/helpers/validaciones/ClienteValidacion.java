package com.example.LogisticAPP.helpers.validaciones;

import org.springframework.stereotype.Component;

@Component
public class ClienteValidacion {

    // Validar que la descripción no sea nula ni vacía
    public boolean validarNombres(String nombres) {
        return nombres != null && !nombres.trim().isEmpty();
    }

    // Validar que el departamento no sea nulo ni vacío
    public boolean validarDepartamento(String departamento) {
        return departamento != null && !departamento.trim().isEmpty();
    }

    // Validar que el municipio no sea nulo ni vacío
    public boolean validarMunicipio(String municipio) {
        return municipio != null && !municipio.trim().isEmpty();
    }

    // Validar que la dirección no sea nula ni vacía
    public boolean validarDireccion(String direccion) {
        return direccion != null && !direccion.trim().isEmpty();
    }

    // Validar que el código postal no sea nulo ni vacío y cumpla con un patrón (opcional)
    public boolean validarCodigoPostal(String codigoPostal) {
        return codigoPostal != null && !codigoPostal.trim().isEmpty() && codigoPostal.matches("\\d{5}"); // Ejemplo: código postal de 5 dígitos
    }

    // Validar que el rol no sea nulo ni vacío
    public boolean validarRol(String rol) {
        return rol != null && !rol.trim().isEmpty();
    }

    // Validar que el email sea válido
    public boolean validarEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$"); // Ejemplo de patrón simple para email
    }

    // Validar que el teléfono no sea nulo ni vacío
    public boolean validarTelefono(String telefono) {
        return telefono != null && !telefono.trim().isEmpty() && telefono.matches("\\d{10}"); // Ejemplo: número de 10 dígitos
    }
}