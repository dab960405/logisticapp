package com.example.LogisticAPP.servicios;

import com.example.LogisticAPP.helpers.mensajes.MensajesError;
import com.example.LogisticAPP.helpers.validaciones.ZonaBodegaValidacion;
import com.example.LogisticAPP.modelos.ZonaBodega;
import com.example.LogisticAPP.repositorios.IZonaBodegaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ZonaBodegaServicio {

    // INYECTAR LA DEPENDENCIA AL REPOSITORIO
    @Autowired
    private IZonaBodegaRepositorio consultaEnBD;

    @Autowired
    private ZonaBodegaValidacion validacion; // Asegúrate de tener esta clase de validación

    // Registrar en BD una zona de bodega
    public ZonaBodega registrar(ZonaBodega datosZonaBodega) throws Exception {
        try {
            // Validaciones
            if (!this.validacion.validarNombreZona(datosZonaBodega.getNombreZona())) {
                throw new Exception(MensajesError.NOMBRES_INVALIDOS.getMensaje());
            }
            if (!this.validacion.validarVolumenMaximo(datosZonaBodega.getVolumenMaximo())) {
                throw new Exception(MensajesError.VOLUMEN_INVALIDO.getMensaje());
            }
            if (!this.validacion.validarPesoMaximo(datosZonaBodega.getPesoMaximo())) {
                throw new Exception(MensajesError.PESO_INVALIDO.getMensaje());
            }
            if (!this.validacion.validarVolumenOcupado(datosZonaBodega.getVolumenOcupado())) {
                throw new Exception(MensajesError.VOLUMEN_OCUPADO_INVALIDO.getMensaje());
            }
            if (!this.validacion.validarPesoOcupado(datosZonaBodega.getPesoOcupado())) {
                throw new Exception(MensajesError.PESO_OCUPADO_INVALIDO.getMensaje());
            }
            return this.consultaEnBD.save(datosZonaBodega);
        } catch (Exception error) {
            throw new Exception(error.getMessage());
        }
    }

    // Consultar la información de todas las zonas de bodega
    public List<ZonaBodega> buscarZonasBodega() throws Exception {
        try {
            return this.consultaEnBD.findAll();
        } catch (Exception error) {
            throw new Exception(error.getMessage());
        }
    }
}
