package com.example.LogisticAPP.helpers.validaciones;

import org.springframework.stereotype.Component;

@Component
public class ZonaBodegaValidacion {

    public boolean validarNombreZona(String nombreZona) {
        return nombreZona != null && nombreZona.length() <= 50;
    }

    public boolean validarVolumenMaximo(Double volumenMaximo) {
        return volumenMaximo != null && volumenMaximo > 0;
    }

    public boolean validarPesoMaximo(Double pesoMaximo) {
        return pesoMaximo != null && pesoMaximo > 0;
    }

    public boolean validarVolumenOcupado(Double volumenOcupado) {
        return volumenOcupado != null && volumenOcupado > 0;
    }

    public boolean validarPesoOcupado(Double pesoOcupado) {
        return pesoOcupado != null && pesoOcupado > 0;
    }

}

