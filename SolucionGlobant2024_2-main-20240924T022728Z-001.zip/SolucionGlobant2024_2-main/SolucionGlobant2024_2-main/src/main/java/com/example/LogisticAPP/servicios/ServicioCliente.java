package com.example.LogisticAPP.servicios;

import com.example.LogisticAPP.helpers.mensajes.MensajesError;
import com.example.LogisticAPP.helpers.validaciones.ClienteValidacion;
import com.example.LogisticAPP.modelos.Cliente;
import com.example.LogisticAPP.repositorios.IClienteRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioCliente {

    @Autowired
    private IClienteRepositorio clienteRepositorio;

    @Autowired
    private ClienteValidacion validacion; // Asegúrate de tener esta clase de validación

    // Registrar un nuevo cliente
    public Cliente registrar(Cliente datosCliente) throws Exception {
        try {
            // Validaciones
            if (!this.validacion.validarNombres(datosCliente.getNombres())) {
                throw new Exception(MensajesError.NOMBRES_INVALIDOS.getMensaje());
            }
            if (!this.validacion.validarEmail(datosCliente.getEmail())) {
                throw new Exception(MensajesError.EMAIL_INVALIDO.getMensaje());
            }
            // Puedes agregar más validaciones según sea necesario

            return this.clienteRepositorio.save(datosCliente);
        } catch (Exception error) {
            throw new Exception(error.getMessage());
        }
    }

    // Consultar la información de todos los clientes
    public List<Cliente> buscarClientes() throws Exception {
        try {
            return this.clienteRepositorio.findAll();
        } catch (Exception error) {
            throw new Exception(error.getMessage());
        }
    }
}
